"""Opt-in tiny synthetic CUDA/NCCL capture through production spawned workers."""
import json
import os
from pathlib import Path
import sys
import time

import pytest
import torch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_pipeline_worker_runtime import checkpoint, free_port
from engine.core import EngineCore
from samplingParams import SamplingParams
from utils.observation_config import configure_observation
from utils.observed_runner import ObservedModelRunner, ObservedPipelineTransport
from utils.trace_audit import audit_trace

pytestmark=pytest.mark.skipif(os.getenv('PP_TEST_BACKEND')!='nccl',reason='explicit CUDA correctness/profile smoke only')


@pytest.mark.parametrize('pp,tp',[(1,2),(2,2)])
def test_spawned_cuda_trace_and_unprofiled_throughput(tmp_path,monkeypatch,pp,tp):
    monkeypatch.setenv('VLLM_LEARN_REFERENCE_MATH','1')
    monkeypatch.setenv('VLLM_LEARN_ATTENTION_BACKEND','sdpa_reference')
    monkeypatch.setenv('VLLM_LEARN_EXPERT_BACKEND','loop')
    monkeypatch.setenv('VLLM_LEARN_WORKER_TIMEOUT_S','90')
    model=tmp_path/'tiny'
    checkpoint(model)
    outputs=[]
    for profiled in (False,True):
        out=tmp_path/('profile' if profiled else 'bench')
        configure_observation(out,profile=profiled,start_message=2,messages=2)
        core=EngineCore(str(model),tp_size=tp,pp_size=pp,enable_expert_parallel=True,
            master_port=free_port(),gpus=list(range(pp*tp)),
            runner_cls=ObservedModelRunner,transport_cls=ObservedPipelineTransport,
            pipeline_microbatch_tokens=8,config_kwargs=dict(max_model_len=128,
            max_num_batched_tokens=8,max_num_seqs=16,gpu_memory_utilization=.98,
            max_kvcache_blocks=16,enforce_eager=True))
        try:
            started=time.perf_counter()
            result=core.generate([[1,2],[3,4,5],[1,2]],SamplingParams(temperature=0.,max_tokens=4,ignore_eos=True))
            elapsed=time.perf_counter()-started
            outputs.append([tokens for _,tokens in result])
        finally:
            core.shutdown()
        assert all(len(tokens)==4 for tokens in outputs[-1])
        if not profiled:
            assert not list(out.glob('trace/*.json'))
            assert elapsed>0
            (out/'smoke_throughput.json').write_text(json.dumps(dict(output_tokens=12,
                wall_s=elapsed,output_tok_s=12/elapsed,scope='tiny synthetic smoke, not30B/performance result')))
        else:
            traces=sorted((out/'trace').glob('cuda_rank*.json'))
            assert len(traces)==pp*tp
            audits=[]
            for trace in traces:
                audit=audit_trace(trace)
                assert audit['cpu_ops']>0 and audit['cuda_runtime']>0,audit
                assert audit['gpu_kernels']>0 and audit['nccl_kernels']>0,audit
                assert any('.attention' in name for name in audit['module_labels']),audit
                assert any('.moe' in name for name in audit['module_labels']),audit
                audits.append(audit)
            (out/'validation.json').write_text(json.dumps(audits,indent=2))
    assert outputs[0]==outputs[1]  # Profiling observer must not change generated tokens.
