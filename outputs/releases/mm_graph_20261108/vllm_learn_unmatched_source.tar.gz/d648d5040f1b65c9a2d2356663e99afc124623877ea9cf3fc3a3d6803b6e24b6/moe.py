# v6/layers/moe.py
"""MoE 路由、本地专家权重与变长 EP dispatch/combine。

设计（对齐我们"平铺批 + context"的架构）：
  - 输入是平铺的 [total_q, hidden]（与 attention 同一约定）；
  - router：softmax(fp32) → topk → normalize（HF Qwen3MoeTopKRouter 逐行同数学）；
  - experts：按 expert_idx 排序 token，Python 循环调用各非空专家的两个 GEMM；
    尚不是单次 fused grouped GEMM。w13 为 [E_local, 2*I_local, H]，
    w2 为 [E_local, H, I_local]。

EP 使用独立 ep_group 做变长 dispatch/combine；模型层只负责路由和本地
grouped expert，通信协议仍由组件封装，避免 model_runner 了解专家布局。"""
import os

import torch
import torch.nn as nn
import torch.nn.functional as F


def _reduce_routes(routes, expert_ids):
    """Reduce returned top-k routes; the HF order is a diagnostic oracle."""
    if os.getenv('VLLM_LEARN_MOE_REDUCTION', 'fp32') == 'hf_reference':
        order = expert_ids.argsort(dim=-1)
        routes = routes.gather(1, order[..., None].expand_as(routes))
        output = torch.zeros_like(routes[:, 0])
        for slot in range(routes.shape[1]):
            output = output + routes[:, slot]
        return output
    return routes.float().sum(dim=1).to(routes.dtype)


class MoERouter(nn.Module):
    """模型 dtype 的 logits、FP32 softmax 与 top-k；支持显式 FP32 消融。"""

    def __init__(self, hidden_size: int, num_experts: int, top_k: int,
                 norm_topk_prob: bool = True):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(num_experts, hidden_size))
        self.top_k = top_k
        self.norm_topk_prob = norm_topk_prob
        self.num_experts = num_experts
        # HF computes logits in model dtype before FP32 softmax. An explicit
        # FP32 logits policy remains available for numerical ablations.
        self.logits_dtype = os.getenv("VLLM_LEARN_ROUTER_LOGITS_DTYPE", "model")
        if self.logits_dtype not in ("float32", "model"):
            raise ValueError("router logits dtype must be float32 or model")

    def weight_loader(self, param, loaded, shard_id=None):
        """HF 名 mlp.gate.weight（loader 已映射到 router.weight）。直装。"""
        assert param.shape == loaded.shape
        param.data.copy_(loaded)

    def forward(self, x: torch.Tensor):
        """x: [T, H] → (topk_idx [T,k], topk_w [T,k])。"""
        logits = (F.linear(x, self.weight) if self.logits_dtype == "model"
                  else F.linear(x.float(), self.weight.float()))
        probs = logits.softmax(dim=-1, dtype=torch.float32)
        w, idx = probs.topk(self.top_k, dim=-1)
        if self.norm_topk_prob:
            w = w / w.sum(dim=-1, keepdim=True)
        return idx, w.to(x.dtype)


class GroupedExperts(nn.Module):
    """128 个专家的分组计算。权重三块：
      w13: [E, 2*I, H]  gate|up 融合（一个 gemm 出两半）
      w2:  [E, H, I]    down
    forward 按 expert 分组排序后 gather → 两个 grouped gemm → scatter 加权回去。"""

    def __init__(self, num_experts: int, hidden_size: int, intermediate: int):
        super().__init__()
        from layers.parallel import STATE
        self.hidden = hidden_size
        # ---- EP: 本地专家区间 ----
        per = num_experts // STATE.ep_size
        assert per * STATE.ep_size == num_experts, \
            f"E={num_experts} 切不动 EP{STATE.ep_size}"
        self.e_start = STATE.ep_rank * per
        self.num_experts = per                    # 本地专家数（E_local）
        # ---- TP: inter 切片（w13 的行 / w2 的列）----
        assert intermediate % STATE.tp_size == 0, \
            f"I={intermediate} 切不动 TP{STATE.tp_size}"
        self.inter = intermediate // STATE.tp_size       # I_local
        self.i_start = STATE.tp_rank * self.inter
        self.quantized = False
        # Opt-in native grouped GEMM: two grouped API calls for local experts,
        # without copying weights per route or reading expert counts on CPU.
        # The backend determines the actual number of CUDA kernel launches.
        # Keep the validated reference loop as the default.  ``auto`` is an
        # explicit performance mode selected by the benchmark/serving policy.
        self.backend = os.getenv('VLLM_LEARN_EXPERT_BACKEND', 'loop')
        if self.backend not in ('auto', 'loop', 'torch_grouped'):
            raise ValueError('expert backend must be auto, loop, or torch_grouped')
        # Optional experiment-only counters.  They stay disabled in normal
        # inference; enabling VLLM_LEARN_PROFILE_EXPERTS records token routing
        # and all-to-all volume for long-tail/hot-expert analysis.
        self._profile_enabled = os.getenv("VLLM_LEARN_PROFILE_EXPERTS", "0") == "1"
        self._profile_token_counts = None
        self._profile_send_counts = None
        self._profile_recv_counts = None
        self.w13 = nn.Parameter(torch.empty(self.num_experts, 2 * self.inter, hidden_size))
        self.w2 = nn.Parameter(torch.empty(self.num_experts, hidden_size, self.inter))

    def quantize_int4(self, group: int = 128):
        """在线量化：装载完 bf16 权重后调用，就地转 int4 打包 buffer。
        权重显存 -75%（专家占模型 ~80%，是量化收益主体）。"""
        from layers.quantized import rtn_quantize
        E, _, H = self.w13.shape
        I = self.w2.shape[-1]
        p13, s13 = rtn_quantize(self.w13.data.float().reshape(E * 2 * I, H), group)
        p2, s2 = rtn_quantize(self.w2.data.float().reshape(E * H, I), group)
        # 平铺 2D 存储避免 reshape 维度混乱（packed 维 = 最后一维 K/2）
        self.register_buffer("w13_packed", p13)            # [E*2I, H/2]
        self.register_buffer("w13_scales", s13)            # [E*2I, H/g]
        self.register_buffer("w2_packed", p2)              # [E*H, I/2]
        self.register_buffer("w2_scales", s2)              # [E*H, I/g]
        self.group = group
        del self.w13, self.w2                      # 释放 bf16 权重
        self.quantized = True

    def weight_loader(self, param, loaded, shard_id=None):
        """weight_loader 协议（与 BaseLinear/RmsNorm 同约定）：
        loader 做名字映射后调 param 所属模块的 weight_loader，shard_id 携带
        融合信息——(expert_idx, half) 装进 w13 的对应半区，(expert_idx, None) 装 w2。

        并行处理（v9.3）：loaded 是【全量单专家】张量，组件内部切好再装——
          非本地专家（EP 区间外）→ 跳过
          w13: gate/up 半区里各取 inter 的本 rank 行段；w2: 列段
        TP 切缝与 gate|up 边界对齐（I % tp==0 保证不跨缝）；
        loader 完全不感知并行。"""
        i, half = shard_id
        if not (self.e_start <= i < self.e_start + self.num_experts):
            return                                     # EP: 非本地专家
        li = i - self.e_start                          # 本地专家下标
        s, e = self.i_start, self.i_start + self.inter
        if param is self.w13:
            # loaded 是 gate 或 up 的【半张量】[I_full, H]（loader 的 _ckpt_name
            # 已按 gate/up 拆 shard）——直接取本 rank 的 inter 行段
            param.data[li, half * self.inter:(half + 1) * self.inter, :] = loaded[s:e, :]
        else:
            param.data[li] = loaded[:, s:e]


    def forward(self, x: torch.Tensor, topk_idx: torch.Tensor, topk_w: torch.Tensor) -> torch.Tensor:
        """x: [T, H]; topk_idx: [T, k]; topk_w: [T, k] → [T, H]。
        按专家分组：每专家一次 [n_e, H] gemm（激活只含该专家的 token，
        权重不复制——朴素 einsum 会把专家权重按 token 复制 T*k 份直接爆显存）。
        counts 的 CPU 同步每层一次（v6.1 优化：预分配分段表）。"""
        T, H = x.shape
        k = topk_idx.shape[1]
        E = self.num_experts

        # (T, k) → 按 expert 分组的 (token, weight) 列表
        flat_expert = topk_idx.reshape(-1)
        flat_token = torch.arange(T, device=x.device).repeat_interleave(k)
        flat_w = topk_w.reshape(-1)

        route_out = torch.empty((T * k, H), device=x.device, dtype=x.dtype)
        counts = torch.bincount(flat_expert, minlength=E)
        if self._profile_enabled:
            c = counts.detach().cpu()
            self._profile_token_counts = c if self._profile_token_counts is None else self._profile_token_counts + c
        offsets = counts.cumsum(0)                     # 每个专家在排序后序列的终点
        # 稳定排序：同一专家的 token 连续排布
        order = torch.argsort(flat_expert, stable=True)
        sorted_token = flat_token[order]
        sorted_w = flat_w[order]

        xs = x[sorted_token]
        out = self.compute_sorted(xs, offsets)
        route_out[order] = out * sorted_w[:, None].to(out.dtype)
        return _reduce_routes(route_out.view(T, k, H), topk_idx)

    def compute_sorted(self, xs, offsets, offsets_host=None):
        """Compute expert-contiguous routes using local weights only.

        ``offsets[e]`` is the exclusive end of expert e, including empty
        experts. Native grouped GEMM keeps this prefix sum on the GPU.
        Explicit selection fails on unsupported platforms instead of silently
        falling back to the Python loop and mislabelling measurements.
        ``offsets_host``: caller-supplied host endpoints — skips the
        ``offsets.tolist()`` D2H sync in the loop backend.
        """
        if self.quantized:
            from layers.quantized import dequantize
            g = self.group
            # 平铺 [E*2I, H/2] → 按需 dequant（本版全量；v9.2 kernel 化后按 tile）
            w13 = dequantize(self.w13_packed, self.w13_scales, g).reshape(self.num_experts, -1, self.hidden).to(xs.dtype)
            w2 = dequantize(self.w2_packed, self.w2_scales, g).reshape(self.num_experts, self.hidden, self.inter).to(xs.dtype)
        else:
            w13, w2 = self.w13, self.w2
        if xs.shape[0] == 0:
            return xs.new_empty((0, self.hidden))
        backend = self.resolve_backend(xs)
        with torch.autograd.profiler.record_function(f'moe.experts.{backend}'):
            return self._compute_sorted_backend(xs, offsets, w13, w2, backend,
                                                offsets_host)

    def resolve_backend(self, xs):
        """Select the grouped kernel for supported CUDA BF16 inputs.

        Explicit ``torch_grouped`` stays strict for reproducible ablations;
        ``auto`` falls back to the readable loop on unsupported platforms.
        """
        if self.backend != 'auto':
            return self.backend
        grouped_mm = getattr(F, 'grouped_mm', None) or getattr(torch, '_grouped_mm', None)
        if xs.is_cuda and xs.dtype == torch.bfloat16 and grouped_mm is not None:
            return 'torch_grouped'
        return 'loop'

    def _compute_sorted_backend(self, xs, offsets, w13, w2, backend,
                                offsets_host=None):
        if backend == 'torch_grouped':
            grouped_mm = getattr(F, 'grouped_mm', None) or getattr(torch, '_grouped_mm', None)
            if grouped_mm is None or not xs.is_cuda or xs.dtype != torch.bfloat16:
                raise RuntimeError('torch_grouped requires CUDA BF16 and a compatible native grouped_mm')
            offs = offsets.to(dtype=torch.int32)
            h13 = grouped_mm(xs, w13.transpose(-2, -1), offs=offs)
            gate, up = h13.chunk(2, dim=-1)
            act = F.silu(gate) * up
            return grouped_mm(act, w2.transpose(-2, -1), offs=offs)
        output = xs.new_empty((xs.shape[0], self.hidden))
        start = 0
        ends = offsets_host if offsets_host is not None else offsets.tolist()
        for e, end in enumerate(ends):
            if end == start:                           # 本批没 token 命中该专家
                continue
            h13 = xs[start:end] @ w13[e].t()           # [n_e, 2I]
            gate, up = h13.chunk(2, dim=-1)
            act = F.silu(gate) * up                    # [n_e, I]
            out = act @ w2[e].t()                      # [n_e, H]
            output[start:end] = out
            start = end
        return output


class MoEMLP(nn.Module):
    """一层完整 MoE：router + experts。无共享专家（Qwen3-Omni 配置为 0）。

    EP 模式（v6.2）：expert_parallel=True 时——
      1. 本地 experts 只持有自己一半专家的权重（loader/shard 切）；
      2. router 全卡跑（全专家 logits，冗余）；
      3. dispatch: 把 (token, expert, weight) 中 expert 属于对端的条目 all-to-all 发过去；
      4. 本地算完 partial 和，combine: all-to-all 收回对端算的结果，就地累加。
    通信量 = 2 × tokens × h × 2B（每层），与 TP 的 b×s×h×N 倍形成对照。"""

    def __init__(self, config):
        super().__init__()
        # EngineCore broadcasts the same attention batch to every EP rank.
        # Opt-in token ownership avoids computing those MoE routes EP times.
        # Keep the general all-to-allv primitive valid for distinct source batches.
        self.shard_replicated_input = os.getenv("VLLM_LEARN_EP_SHARD_REPLICATED_INPUT", "0") == "1"
        # Routing probabilities are already known by the source. Keeping the
        # BF16 multiply there removes one metadata collective per MoE layer.
        self.weight_at_source = os.getenv('VLLM_LEARN_EP_WEIGHT_AT_SOURCE', '0') == '1'
        # BF16 GEMM algorithms depend on M. Routing an ownership slice can
        # round logits differently from the identical replicated attention
        # batch, changing top-k weights and occasionally expert selection.
        # Default to the same router shape as EP1; local routing is opt-in.
        self.local_router = os.getenv('VLLM_LEARN_EP_LOCAL_ROUTER', '0') == '1'
        # Experimental replicated-input fast path (see _ep_forward_fast):
        # analytic metadata (one D2H per layer, no counts a2a), packed
        # dispatch payload, source-side weighting -> 2 collectives/layer.
        self.fastmeta = os.getenv('VLLM_LEARN_EP_FASTMETA', '0') == '1'
        # Optional second-communicator pipeline: parity-split routes,
        # dispatch(B) overlaps experts(A), combine(A) overlaps experts(B).
        self.overlap = (self.fastmeta
                        and os.getenv('VLLM_LEARN_EP_OVERLAP', '0') == '1')
        # Counts provider: 'analytic' relies on replicated inputs (every rank
        # sees the same routes, so all splits are locally derivable).
        # 'exchange' derives the same splits from local counts + one tiny
        # allgather + one D2H — valid for ANY per-rank input batch, i.e. the
        # form a DP×EP-coupled dispatch group (vLLM style) would need.
        # On replicated inputs both providers must produce identical splits
        # (equivalence is token-level checkable today).
        self.meta_mode = os.getenv('VLLM_LEARN_EP_META', 'analytic')
        self._ov_streams = None
        self._rowmap_cache = {}
        self.router = MoERouter(config.hidden_size, config.num_experts,
                                config.num_experts_per_tok,
                                getattr(config, "norm_topk_prob", True))
        self.experts = GroupedExperts(config.num_experts, config.hidden_size,
                                      config.moe_intermediate_size)
        # v9.3: 并行状态在 GroupedExperts 内部（构造时从 ParallelState 读）,
        # MoEMLP 只负责 router + 本地计算 + 部分和聚合

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        from layers.parallel import STATE, tp_allreduce
        if STATE.ep_size > 1 and self.shard_replicated_input:
            return self._forward_replicated_input(x)
        with torch.autograd.profiler.record_function("moe.router"):
            idx, w = self.router(x)
        if STATE.ep_size > 1 and not self.shard_replicated_input and \
                self.fastmeta and x.dtype == torch.bfloat16:
            out = self._ep_forward_fast(x, idx, w)
            return tp_allreduce(out)
        if STATE.ep_size > 1:
            # EP uses variable-size dispatch/combine.  Every destination
            # receives exactly the token count for its local experts; no
            # [world, max_tokens] padding or full-token replication.
            out = self._ep_forward_alltoallv(x, idx, w)
            # combine all-to-all has already returned every destination
            # expert contribution to the origin rank. Only TP reduction remains
            # because each TP rank owns a slice of the expert intermediate dim.
            return tp_allreduce(out)
        return tp_allreduce(self.experts(x, idx, w))

    def _forward_replicated_input(self, x):
        """Shard routes for an identical input batch on every EP rank.

        Attention remains replicated. Each EP origin owns a contiguous token
        interval, so the distributed experts evaluate each top-k route once.
        Gather restores the replicated output expected by the next layer.
        This wrapper requires identical x and token order on all EP peers;
        _ep_forward_alltoallv itself still supports arbitrary source lengths.
        """
        from layers.parallel import STATE, tp_allreduce
        import torch.distributed as dist
        tokens, hidden = x.shape
        if tokens == 0:
            return x
        rows = (tokens + STATE.ep_size - 1) // STATE.ep_size
        start = STATE.ep_rank * rows
        local_x = x[start:min(start + rows, tokens)]
        with torch.autograd.profiler.record_function("moe.router.local_tokens"):
            if self.local_router:
                ids, weights = self.router(local_x)
            else:
                all_ids, all_weights = self.router(x)
                ids, weights = all_ids[start:start + rows], all_weights[start:start + rows]
        local_out = tp_allreduce(self._ep_forward_alltoallv(local_x, ids, weights))
        # NCCL all_gather_into_tensor requires equal sizes. This pads only the
        # ownership boundary (at most ep_size-1 rows across the whole group),
        # never expert activations to a hottest-expert capacity.
        padded = torch.zeros((rows, hidden), device=x.device, dtype=x.dtype)
        padded[:local_out.shape[0]].copy_(local_out)
        output = torch.empty((rows * STATE.ep_size, hidden), device=x.device, dtype=x.dtype)
        with torch.autograd.profiler.record_function("moe.restore_replicated_output"):
            dist.all_gather_into_tensor(output, padded, group=STATE.ep_group)
        return output[:tokens]

    def _experts_local(self, xs, eids, ws=None):
        """本地专家子集的分组计算（eids 是本地编号）。"""
        E = self.experts.num_experts
        final = torch.empty_like(xs)
        counts = torch.bincount(eids, minlength=E)
        if self.experts._profile_enabled:
            c = counts.detach().cpu()
            self.experts._profile_token_counts = (
                c if self.experts._profile_token_counts is None
                else self.experts._profile_token_counts + c)
        offsets = counts.cumsum(0)
        order = torch.argsort(eids, stable=True)
        xs_s = xs[order]
        out = self.experts.compute_sorted(xs_s, offsets)
        final[order] = out if ws is None else out * ws[order, None].to(out.dtype)
        return final

    def _ep_forward_alltoallv(self, x, idx, w):
        """Variable-length EP dispatch and combine using NCCL all-to-allv.

        The flattened route entries are grouped by destination EP rank.  The
        destination computes only its local experts and returns outputs in the
        same per-peer order, allowing the sender to scatter-add directly into
        its original token rows.  ``send_counts``/``recv_counts`` are exchanged
        first, so hot experts create real larger messages instead of padding.
        """
        from layers.parallel import STATE
        if STATE.ep_group is None:
            raise RuntimeError("EP all-to-allv requires an ep_group")
        import torch.distributed as dist
        T, H = x.shape
        k = idx.shape[1]
        experts_per_rank = self.experts.num_experts
        flat_e = idx.reshape(-1).to(torch.int64)
        flat_w = w.reshape(-1)
        flat_t = torch.arange(T, device=x.device, dtype=torch.int64).repeat_interleave(k)
        dest = torch.div(flat_e, experts_per_rank, rounding_mode="floor")
        order = torch.argsort(dest, stable=True)
        send_e = flat_e[order].contiguous()
        send_w = flat_w[order].contiguous()
        send_t = flat_t[order].contiguous()
        send_x = x[send_t].contiguous()
        world = STATE.ep_size
        send_counts = torch.bincount(dest, minlength=world).to(torch.int64)
        recv_counts = torch.empty_like(send_counts)
        dist.all_to_all_single(recv_counts, send_counts, group=STATE.ep_group)
        if self.experts._profile_enabled:
            sc, rc = send_counts.detach().cpu(), recv_counts.detach().cpu()
            self.experts._profile_send_counts = sc if self.experts._profile_send_counts is None else self.experts._profile_send_counts + sc
            self.experts._profile_recv_counts = rc if self.experts._profile_recv_counts is None else self.experts._profile_recv_counts + rc
        ss = [int(v) for v in send_counts.tolist()]
        rs = [int(v) for v in recv_counts.tolist()]

        def a2a(inp, out_shape, splits_in, splits_out):
            out = torch.empty(out_shape, dtype=inp.dtype, device=inp.device)
            dist.all_to_all_single(out, inp, output_split_sizes=splits_out,
                                   input_split_sizes=splits_in, group=STATE.ep_group)
            return out

        with torch.autograd.profiler.record_function("moe.dispatch"):
            recv_x = a2a(send_x, (sum(rs), H), ss, rs)
        recv_e = a2a(send_e, (sum(rs),), ss, rs)
        recv_w = None if self.weight_at_source else a2a(send_w, (sum(rs),), ss, rs)
        # Convert global expert ids to this rank's local interval.
        local_e = recv_e - STATE.ep_rank * experts_per_rank
        with torch.autograd.profiler.record_function("moe.expert"):
            recv_out = self._experts_local(recv_x, local_e, recv_w)
        with torch.autograd.profiler.record_function("moe.combine"):
            returned = a2a(recv_out, (sum(ss), H), rs, ss)
        # Each flattened route has exactly one output. Restore route order,
        # then sum top-k in FP32 instead of BF16 atomic index_add_. Atomic
        # accumulation order varies across launches and can change greedy
        # tokens when scores are close (and can diverge across EP replicas).
        route_out = torch.empty_like(returned)
        route_out[order] = (returned * send_w[:, None].to(returned.dtype)
                            if self.weight_at_source else returned)
        return _reduce_routes(route_out.view(T, k, H), idx)

    # ============ experimental fast path (VLLM_LEARN_EP_FASTMETA) ============

    def _meta_host(self, *tensors):
        """一次 D2H 同步取回全部元数据(list[int] 拼接)。"""
        return torch.cat(tensors).tolist()

    def _expert_ends_host(self, counts, me, per, world):
        """host 侧专家终点（cumsum）：本 rank 收到 expert e 的行数 = world ×
        每个 source 发往 e 的路由数（复制输入下各 source 相同）。"""
        ends, acc = [], 0
        for e in range(me * per, (me + 1) * per):
            acc += world * counts[e]
            ends.append(acc)
        return ends

    def _local_experts_host(self, recv, rows, me, per, ends_host, H):
        """接收缓冲 → 专家计算（带 host 偏移，无 .tolist() 同步）。"""
        rx = recv[:, :H]
        le = recv[:, H].contiguous().view(torch.int16).to(torch.int64) \
            - me * per
        rorder = torch.argsort(le, stable=True)
        xs_s = rx[rorder]
        offs_gpu = torch.tensor(ends_host, dtype=torch.int32,
                                device=rx.device)
        out_s = self.experts.compute_sorted(xs_s, offs_gpu,
                                            offsets_host=ends_host)
        final = torch.empty((rows, H), dtype=rx.dtype, device=rx.device)
        final[rorder] = out_s
        return final

    def _pack(self, x, rows, k, flat_e, H):
        """把 (token 行 | int16 专家号) 打包成单个 bf16 载荷 [n, H+1]。"""
        return torch.cat([x[rows // k],
                          flat_e[rows].to(torch.int16).unsqueeze(1)
                                      .view(torch.bfloat16)], dim=1)

    def _counts_host(self, gcE, gcD, world, me, per, E):
        """一次 D2H 解析 (send_splits, recv_splits, 本地专家终点)。

        analytic：仅当输入在 EP 组内复制时成立——计数矩阵是外积，
        所有人的 send/recv 与专家偏移本地可推，零额外交集通信。
        exchange：对任意 per-rank 批次成立（DP×EP 耦合形态）——本地
        bincount + 一次打包 allgather(E+world 个 int32) + 一次 D2H。
        复制输入下两者必须给出完全相同的 splits（可逐 token 验证）。
        """
        if self.meta_mode == 'exchange':
            from layers.parallel import STATE
            import torch.distributed as dist
            W = E + world
            cnt = torch.cat([gcE, gcD]).to(torch.int32)
            gathered = torch.empty(world * W, dtype=torch.int32,
                                   device=gcE.device)
            dist.all_gather_into_tensor(gathered, cnt, group=STATE.ep_group)
            meta = gathered.tolist()                  # <<< 每层唯一一次 D2H
            ssl = meta[me * W + E: me * W + E + world]
            rs = [meta[j * W + E + me] for j in range(world)]
            ends, acc = [], 0
            for e in range(me * per, (me + 1) * per):
                acc += sum(meta[j * W + e] for j in range(world))
                ends.append(acc)
            return ssl, rs, ends
        meta = self._meta_host(gcE, gcD)              # <<< 每层唯一一次 D2H
        gcl, ssl = meta[:E], meta[E:]
        rs = [ssl[me]] * world
        return ssl, rs, self._expert_ends_host(gcl, me, per, world)

    def _ep_forward_fast(self, x, idx, w):
        """复制输入下的解析化 EP 路径（env 门控实验）。

        事实依据：所有 EP rank 持有相同的 token batch 与相同的路由表 →
        计数矩阵是外积（每个 source 发往 dest d 的行数相同），于是
        send/recv splits 与本 rank 的专家偏移只需一次 bincount 链 +
        一次 D2H 即可在 host 解析——消掉：计数 all_to_all、2 次 counts
        tolist、expert 循环的 offsets tolist。
        载荷打包 (x|int16 e) + 源侧加权把每层集合通信从 5 次压到 2 次
        （dispatch + combine）。数学与默认路径逐行一致（GEMM 形状不变）。
        overlap 子路径再把路由按 top-k 槽位奇偶拆到两条通信域流水：
        dispatch(B) ∥ experts(A) ∥ combine(A) ∥ experts(B)。
        """
        from layers.parallel import STATE
        import torch.distributed as dist
        T, H = x.shape
        if T == 0:
            return x
        k = idx.shape[1]
        world, me = STATE.ep_size, STATE.ep_rank
        per = self.experts.num_experts
        E = per * world
        flat_e = idx.reshape(-1)
        flat_w = w.reshape(-1)
        dest = torch.div(flat_e, per, rounding_mode="floor")
        if self.overlap and STATE.ep_group2 is not None and k % 2 == 0:
            return self._ep_forward_fast_overlap(x, idx, w, flat_e, flat_w,
                                                 dest)
        with torch.autograd.profiler.record_function("moe.dispatch.meta"):
            gcE = torch.bincount(flat_e, minlength=E)
            gcD = torch.bincount(dest, minlength=world)
            ssl, rs, ends_host = self._counts_host(gcE, gcD, world, me, per, E)
        order = torch.argsort(dest, stable=True)
        packed = self._pack(x, order, k, flat_e, H)
        with torch.autograd.profiler.record_function("moe.dispatch"):
            recv = torch.empty((sum(rs), H + 1), dtype=x.dtype,
                               device=x.device)
            dist.all_to_all_single(recv, packed, output_split_sizes=rs,
                                   input_split_sizes=ssl, group=STATE.ep_group)
        with torch.autograd.profiler.record_function("moe.expert"):
            final = self._local_experts_host(recv, recv.shape[0], me, per,
                                             ends_host, H)
        with torch.autograd.profiler.record_function("moe.combine"):
            returned = torch.empty((order.numel(), H), dtype=x.dtype,
                                   device=x.device)
            dist.all_to_all_single(returned, final, output_split_sizes=ssl,
                                   input_split_sizes=rs,
                                   group=STATE.ep_group)
        full = torch.empty_like(returned)
        full[order] = returned * flat_w[order].unsqueeze(1).to(returned.dtype)
        return _reduce_routes(full.view(T, k, H), idx)

    def _ep_forward_fast_overlap(self, x, idx, w, flat_e, flat_w, dest):
        """双通信域流水的 fastmeta 变体。

        路由按 top-k 槽位奇偶（k=8，偶槽/奇槽各 4 个、天然均衡）拆成两路，
        分别走 STATE.ep_group / ep_group2。事件编排：
            dispatch A ‖ dispatch B（两条 NCCL comm 并行）
            experts  A ‖ dispatch B
            combine  A ‖ experts  B
            combine  B ‖ （本层尾部）
        每个专家 GEMM 的 M 维变为原来一半——数值需 token 级对拍确认。
        """
        from layers.parallel import STATE
        import torch.distributed as dist
        T, H = x.shape
        k = idx.shape[1]
        world, me = STATE.ep_size, STATE.ep_rank
        per = self.experts.num_experts
        E = per * world
        k2 = k // 2
        dmat = dest.view(T, k)
        emat = flat_e.view(T, k)
        dA = dmat[:, 0::2].reshape(-1)
        dB = dmat[:, 1::2].reshape(-1)
        eA = emat[:, 0::2].reshape(-1)
        eB = emat[:, 1::2].reshape(-1)
        with torch.autograd.profiler.record_function("moe.dispatch.meta"):
            bcA = torch.bincount(dA, minlength=world)
            bcB = torch.bincount(dB, minlength=world)
            bcEA = torch.bincount(eA, minlength=E)
            bcEB = torch.bincount(eB, minlength=E)
            if self.meta_mode == 'exchange':
                # 每 rank 打包 [dA(world), dB(world), eA(E), eB(E)] 一次
                # allgather + 一次 D2H——对任意 per-rank 批次成立。
                cnt = torch.cat([bcA, bcB, bcEA, bcEB]).to(torch.int32)
                W2 = cnt.numel()
                gathered = torch.empty(world * W2, dtype=torch.int32,
                                       device=x.device)
                dist.all_gather_into_tensor(gathered, cnt,
                                            group=STATE.ep_group)
                g = gathered.tolist()                 # <<< 每层唯一一次 D2H
                row = me * W2
                ssA = g[row: row + world]
                ssB = g[row + world: row + 2 * world]
                rsA = [g[j * W2 + me] for j in range(world)]
                rsB = [g[j * W2 + world + me] for j in range(world)]
                endsA, acc = [], 0
                for e in range(me * per, (me + 1) * per):
                    acc += sum(g[j * W2 + 2 * world + e] for j in range(world))
                    endsA.append(acc)
                endsB, acc = [], 0
                for e in range(me * per, (me + 1) * per):
                    acc += sum(g[j * W2 + 2 * world + E + e]
                               for j in range(world))
                    endsB.append(acc)
            else:
                meta = self._meta_host(bcA, bcB, bcEA, bcEB)
                ssA = meta[:world]
                ssB = meta[world:2 * world]
                ceA = meta[2 * world:2 * world + E]
                ceB = meta[2 * world + E:]
                rsA = [ssA[me]] * world
                rsB = [ssB[me]] * world
                endsA = self._expert_ends_host(ceA, me, per, world)
                endsB = self._expert_ends_host(ceB, me, per, world)
        # A 子域位置 p ↔ flat route id: token p//k2, slot p%k2 → t*k + 2j
        key = (T, k)
        maps = self._rowmap_cache.get(key)
        if maps is None:
            p = torch.arange(T * k2, device=x.device)
            rmA = (p // k2) * k + 2 * (p % k2)
            maps = (rmA, rmA + 1)
            self._rowmap_cache[key] = maps
        rmA, rmB = maps
        orderA = torch.argsort(dA, stable=True)
        orderB = torch.argsort(dB, stable=True)
        rowsA = rmA[orderA]
        rowsB = rmB[orderB]
        packedA = self._pack(x, rowsA, k, flat_e, H)
        packedB = self._pack(x, rowsB, k, flat_e, H)
        if self._ov_streams is None:
            self._ov_streams = (torch.cuda.Stream(), torch.cuda.Stream())
        sA, sB = self._ov_streams
        main = torch.cuda.current_stream()
        ev_pack = torch.cuda.Event()
        ev_pack.record(main)
        recvA = torch.empty((sum(rsA), H + 1), dtype=x.dtype, device=x.device)
        recvB = torch.empty((sum(rsB), H + 1), dtype=x.dtype, device=x.device)
        with torch.autograd.profiler.record_function("moe.dispatch"):
            with torch.cuda.stream(sA):
                sA.wait_event(ev_pack)
                dist.all_to_all_single(recvA, packedA, output_split_sizes=rsA,
                                       input_split_sizes=ssA,
                                       group=STATE.ep_group)
                ev_dA = torch.cuda.Event()
                ev_dA.record(sA)
            with torch.cuda.stream(sB):
                sB.wait_event(ev_pack)
                dist.all_to_all_single(recvB, packedB, output_split_sizes=rsB,
                                       input_split_sizes=ssB,
                                       group=STATE.ep_group2)
                ev_dB = torch.cuda.Event()
                ev_dB.record(sB)
        with torch.autograd.profiler.record_function("moe.expert"):
            main.wait_event(ev_dA)
            finalA = self._local_experts_host(recvA, recvA.shape[0], me, per,
                                              endsA, H)
        ev_eA = torch.cuda.Event()
        ev_eA.record(main)
        combA = torch.empty((rowsA.numel(), H), dtype=x.dtype, device=x.device)
        with torch.autograd.profiler.record_function("moe.combine"):
            with torch.cuda.stream(sA):
                sA.wait_event(ev_eA)
                dist.all_to_all_single(combA, finalA, output_split_sizes=ssA,
                                       input_split_sizes=rsA,
                                       group=STATE.ep_group)
                ev_cA = torch.cuda.Event()
                ev_cA.record(sA)
        with torch.autograd.profiler.record_function("moe.expert"):
            main.wait_event(ev_dB)
            finalB = self._local_experts_host(recvB, recvB.shape[0], me, per,
                                              endsB, H)
        ev_eB = torch.cuda.Event()
        ev_eB.record(main)
        combB = torch.empty((rowsB.numel(), H), dtype=x.dtype, device=x.device)
        with torch.autograd.profiler.record_function("moe.combine"):
            with torch.cuda.stream(sB):
                sB.wait_event(ev_eB)
                dist.all_to_all_single(combB, finalB, output_split_sizes=ssB,
                                       input_split_sizes=rsB,
                                       group=STATE.ep_group2)
                ev_cB = torch.cuda.Event()
                ev_cB.record(sB)
        main.wait_event(ev_cA)
        main.wait_event(ev_cB)
        full = torch.empty((T * k, H), dtype=x.dtype, device=x.device)
        full[rowsA] = combA * flat_w[rowsA].unsqueeze(1).to(combA.dtype)
        full[rowsB] = combB * flat_w[rowsB].unsqueeze(1).to(combB.dtype)
        return _reduce_routes(full.view(T, k, H), idx)
