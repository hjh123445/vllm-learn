import json
import os
from pathlib import Path
import subprocess
import sys
import time
root = Path('/data/ifly_jyhe23/sparse_graph_20261108')
source = root/'source'
sys.path.insert(0, str(source/'v9/tests'))
from test_pipeline_worker_runtime import checkpoint
model = root/'tiny_model_hd16'
if not model.exists():
    checkpoint(model)
    from safetensors.torch import load_file, save_file
    weights=load_file(str(model/'model.safetensors'))
    for name,value in weights.items():
        weights[name]=value.repeat(4) if value.ndim==1 else value.repeat(
            1 if any(key in name for key in ('embed_tokens', 'lm_head', 'mlp.gate.weight')) else 4, 4)
    save_file(weights,str(model/'model.safetensors'))
    config=json.loads((model/'config.json').read_text())
    text=config['thinker_config']['text_config']
    text.update(hidden_size=64,head_dim=16,moe_intermediate_size=64,intermediate_size=64,
                max_position_embeddings=1024)
    (model/'config.json').write_text(json.dumps(config))
configs = [('single',1,1,1,1,False), ('tp2',2,1,1,1,False),
           ('ep2',2,1,1,1,True), ('dp2ep2',1,2,1,1,True),
           ('dp2tp2ep4',2,2,1,1,True), ('pp2tp2ep2',2,1,2,1,True),
           ('dp2pp2ep2',1,2,2,1,True), ('tp2cp2',2,1,1,2,False),
           ('tp2cp2ep2',2,1,1,2,True), ('dp2tp2cp2ep4',2,2,1,2,True),
           ('dp2tp2pp2ep4',2,2,2,1,True), ('pp2cp2ep1',1,1,2,2,True)]
state = dict(status='running', started=time.time(), jobs=[])
def save(): (root/'parallel_suite.json').write_text(json.dumps(state, indent=2))
save()
try:
    for index,(name,tp,dp,pp,cp,ep) in enumerate(configs):
        cmd=[sys.executable,'v9/tools/validate_parallel_graphs.py','--model',str(model),
             '--output',str(root/'parallel'/name),'--tp',str(tp),'--dp',str(dp),
             '--pp',str(pp),'--cp',str(cp),'--port',str(31983+index)]
        if ep: cmd.append('--ep')
        row=dict(name=name, command=cmd, started=time.time(), status='running')
        state['jobs'].append(row);save()
        with (root/f'parallel_{name}.log').open('w') as log:
            code=subprocess.call(cmd,cwd=source,env=dict(os.environ,OMP_NUM_THREADS='2'),stdout=log,stderr=subprocess.STDOUT)
        row.update(ended=time.time(),returncode=code,status='passed' if code==0 else 'failed');save()
        if code: raise RuntimeError(f'{name} failed')
    state['status']='passed'
except Exception as e:
    state.update(status='failed',error=repr(e));raise
finally:
    state['ended']=time.time();save()
