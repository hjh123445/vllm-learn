"""Update the canonical checkout only when its previous source is unchanged."""
import hashlib
import json
from pathlib import Path
import tarfile

root=Path('/data/ifly_jyhe23/sparse_graph_20261108')
target=Path('/data/ifly_jyhe23/vllm-learn-mm-benchmark-v2-20261108')
manifest=json.loads((root/'deploy_manifest.json').read_text())
for rel,record in manifest.items():
    old=target/rel
    if rel.startswith('v9/'):
        expected=record['base_sha256']
        actual=hashlib.sha256(old.read_bytes().replace(b'\r\n',b'\n')).hexdigest() if old.exists() else None
        if actual!=expected:
            raise RuntimeError(f'canonical source changed independently: {rel}')
with tarfile.open(root/'canonical_before.tar.gz','w:gz') as tf:
    for rel in manifest:
        old=target/rel
        if old.exists():tf.add(old,arcname=rel)
with tarfile.open(root/'deploy.tar.gz') as tf:
    for rel,record in manifest.items():
        data=tf.extractfile(rel).read()
        assert hashlib.sha256(data).hexdigest()==record['sha256'],rel
        dest=target/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        temporary=dest.with_name(dest.name+'.sparse_tmp')
        temporary.write_bytes(data)
        temporary.replace(dest)
for rel,record in manifest.items():
    assert hashlib.sha256((target/rel).read_bytes()).hexdigest()==record['sha256']
(root/'deploy_receipt.json').write_text(json.dumps(dict(canonical=str(target),files=manifest),indent=2))
print('CANONICAL_DEPLOY_VERIFIED',len(manifest))
