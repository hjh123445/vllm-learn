"""Run the reviewable sparse-Graph regression suite in an isolated snapshot."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/data/ifly_jyhe23/sparse_graph_20261108')
source = root / 'source'
model = '/data/ifly_jyhe23/models_omni/Qwen3-Omni-30B-A3B-Instruct'
env = dict(os.environ, OMP_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false', PYTHONPATH=str(source / 'v9'))
state = dict(status='running', started=time.time(), jobs=[])
def save():
    (root/'suite.json').write_text(json.dumps(state, indent=2))
save()
jobs = [
    ('tests', ['-m','pytest','-q','v9/tests'], dict(env, CUDA_VISIBLE_DEVICES='')),
    ('large', ['v9/tools/validate_decode_graph.py','--model',model,'--output',str(root/'large'),
        '--max-batch','256','--max-model-len','1024','--prefill-tokens','2048','--graph-reserve-gib','4',
        '--batches','1','8','9','16','17','32','33','64','65','127','128','129','255','256',
        '--lengths','17','255','256','511','--steps','2','--permute','--mixed-lengths',
        '--random-inputs','--batch-invariant','--strict-batch-invariant','--compare-dense'], env),
    ('mixed', ['v9/tools/validate_mixed_decode.py','--model',model,'--output',str(root/'mixed'),'--graph'], env),
]
try:
    for name, args, job_env in jobs:
        command = [sys.executable, *args]
        row = dict(name=name, command=command, started=time.time(), status='running')
        state['jobs'].append(row); save()
        with (root/f'{name}.log').open('w') as log:
            code = subprocess.call(command, cwd=source, env=job_env, stdout=log, stderr=subprocess.STDOUT)
        row.update(ended=time.time(), returncode=code, status='passed' if code == 0 else 'failed'); save()
        if code:
            raise RuntimeError(f'{name} failed: {code}')
    state['status'] = 'passed'
except Exception as exc:
    state.update(status='failed', error=repr(exc))
    raise
finally:
    state['ended'] = time.time(); save()
