import json
import os
from pathlib import Path
import subprocess
import sys
import time
root=Path('/data/ifly_jyhe23/sparse_graph_20261108')
while True:
    state=json.loads((root/'parallel_suite.json').read_text())
    if state['status']!='running':break
    time.sleep(3)
if state['status']!='passed':raise RuntimeError('parallel suite failed')
subprocess.check_call(['tar','-xzf',str(root/'final_source.tar.gz'),'-C',str(root/'source')])
env=dict(os.environ,OMP_NUM_THREADS='2',PYTHONPATH=str(root/'source/v9'))
model='/data/ifly_jyhe23/models_omni/Qwen3-Omni-30B-A3B-Instruct'
jobs=[('cpu_final',['-m','pytest','-q','v9/tests'],dict(env,CUDA_VISIBLE_DEVICES='')),
 ('gpu_segments',['-m','pytest','-q','v9/tests/test_piecewise_graph.py'],env),
 ('full_final',['v9/tools/validate_decode_graph.py','--model',model,'--output',str(root/'full_final'),
   '--max-batch','8','--max-model-len','512','--prefill-tokens','1024','--batches','1','3','7','8',
   '--lengths','17','255','256','--steps','2','--permute','--mixed-lengths','--random-inputs',
   '--batch-invariant','--strict-batch-invariant','--compare-dense'],env),
 ('real_dp2tp4',['v9/tools/validate_parallel_graphs.py','--model',model,'--output',str(root/'real_dp2tp4'),
   '--tp','4','--dp','2','--ep','--port','32007'],env)]
state=dict(status='running',jobs=[],started=time.time())
def save():(root/'final_checks.json').write_text(json.dumps(state,indent=2))
save()
try:
    for name,args,job_env in jobs:
        cmd=[sys.executable,*args]
        row=dict(name=name,status='running',command=cmd,started=time.time())
        state['jobs'].append(row);save()
        with (root/f'{name}.log').open('w') as log:
            code=subprocess.call(cmd,cwd=root/'source',env=job_env,stdout=log,stderr=subprocess.STDOUT)
        row.update(status='passed' if code==0 else 'failed',ended=time.time(),returncode=code);save()
        if code:raise RuntimeError(f'{name} failed')
    state['status']='passed'
except Exception as e:
    state.update(status='failed',error=repr(e));raise
finally:
    state['ended']=time.time();save()
