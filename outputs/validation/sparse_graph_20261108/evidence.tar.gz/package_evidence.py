import hashlib
import json
from pathlib import Path
import tarfile

root=Path('/data/ifly_jyhe23/sparse_graph_20261108')
summary={}
for name in ('suite','parallel_suite','final_checks'):
    state=json.loads((root/f'{name}.json').read_text())
    assert state['status']=='passed',(name,state)
    summary[name]=state
summary['checks']={}
for directory in ('full','large','full_final','mixed','real_dp2tp4'):
    files=sorted((root/directory).glob('rank*.json'))
    assert len(files)==8,(directory,len(files))
    records=[json.loads(f.read_text()) for f in files]
    rows=[row for d in records for row in d['rows']]
    if directory=='real_dp2tp4':
        assert all(r['logits_exact'] and r['tokens_exact'] and r['kv_exact'] for r in rows)
    elif directory=='mixed':
        assert all(r['exact_logits'] and r['exact_live_kv'] and r['token_order_equal'] for r in rows)
    else:
        assert all(r['exact_logits'] and r['kv_graph_equal'] and r['kv_padded_equal'] and r['tp_ranks_equal']
           and r['permutation_equal'] and r['unpadded_max_abs']==0 and r['dense_logits_equal'] and r['dense_kv_equal'] for r in rows)
        assert all(d['live_kv_unchanged'] for d in records)
    summary['checks'][directory]=dict(rank_steps=len(rows),ranks=len(records),
        captures=[d.get('captures',d.get('graph_capture_count')) for d in records],
        replays=[d.get('replays') for d in records])
summary['parallel']={}
for directory in sorted((root/'parallel').iterdir()):
    records=[json.loads(p.read_text()) for p in directory.glob('rank*.json')]
    rows=[row for d in records for row in d['rows']]
    assert all(r['logits_exact'] and r['tokens_exact'] and r['kv_exact'] for r in rows)
    summary['parallel'][directory.name]=dict(ranks=len(records),rank_steps=len(rows),
        captures=[d['captures'] for d in records],replays=[d['replays'] for d in records])
assert len(summary['parallel'])==12
summary['final_source_sha256']={str(f.relative_to(root/'source')):hashlib.sha256(f.read_bytes()).hexdigest()
    for f in (root/'source/v9').rglob('*.py')}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
with tarfile.open(root/'evidence.tar.gz','w:gz') as tf:
    for f in sorted(root.rglob('*')):
        if not f.is_file() or f.parts[len(root.parts)] in ('source','tiny_model','tiny_model_hd16'):
            continue
        if f.name in ('evidence.tar.gz','artifact_manifest.json'):continue
        tf.add(f,arcname=str(f.relative_to(root)))
(root/'artifact_manifest.json').write_text(json.dumps(dict(
    sha256=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest(),
    bytes=(root/'evidence.tar.gz').stat().st_size),indent=2))
print(json.dumps(summary['checks'],indent=2))
